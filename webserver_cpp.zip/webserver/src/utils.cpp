// ============================================================
// utils.cpp — Logger & Helper Implementations
// ============================================================
#include "utils.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <ctime>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// ---- Logger Singleton --------------------------------------
Logger& Logger::instance() {
    // Guaranteed to be initialized exactly once (C++11 §6.7)
    static Logger inst;
    return inst;
}

Logger::Logger() : logFile_("logs/server.log") {
    // Ensure log directory exists (best-effort)
    std::ofstream f(logFile_, std::ios::app);
    if (!f.is_open()) {
        std::cerr << "[Logger] Warning: cannot open " << logFile_ << "\n";
    }
}

Logger::~Logger() {}

// Internal helper: write one line to both console and log file
static void writeLine(std::mutex& mtx,
                      const std::string& logFile,
                      const std::string& line,
                      bool isError) {
    std::lock_guard<std::mutex> lock(mtx);

    // Console output
    if (isError)
        std::cerr << line << "\n";
    else
        std::cout << line << "\n";

    // File output (append mode)
    std::ofstream f(logFile, std::ios::app);
    if (f.is_open())
        f << line << "\n";
}

void Logger::info(const std::string& message) {
    std::string line = "[" + Utils::currentTimestamp() + "] [INFO]  " + message;
    writeLine(mutex_, logFile_, line, false);
}

void Logger::error(const std::string& message) {
    std::string line = "[" + Utils::currentTimestamp() + "] [ERROR] " + message;
    writeLine(mutex_, logFile_, line, true);
}

void Logger::logRequest(const std::string& clientIp,
                        const std::string& method,
                        const std::string& path,
                        int statusCode) {
    // Format: [timestamp] [REQUEST] 127.0.0.1 GET /index.html 200
    std::ostringstream oss;
    oss << "[" << Utils::currentTimestamp() << "] [REQUEST] "
        << clientIp << " " << method << " " << path
        << " → " << statusCode;
    writeLine(mutex_, logFile_, oss.str(), false);
}

// ---- Utils namespace ---------------------------------------
std::string Utils::currentTimestamp() {
    // Use system_clock for wall-clock time
    auto now    = std::chrono::system_clock::now();
    auto now_t  = std::chrono::system_clock::to_time_t(now);
    std::tm tm_buf{};
    localtime_r(&now_t, &tm_buf);  // Thread-safe version of localtime

    std::ostringstream oss;
    oss << std::put_time(&tm_buf, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

std::string Utils::getClientIp(int client_fd) {
    struct sockaddr_in addr{};
    socklen_t len = sizeof(addr);

    // getpeername() fills addr with the remote end's IP:port
    if (getpeername(client_fd, (struct sockaddr*)&addr, &len) == 0) {
        return std::string(inet_ntoa(addr.sin_addr));
    }
    return "unknown";
}
