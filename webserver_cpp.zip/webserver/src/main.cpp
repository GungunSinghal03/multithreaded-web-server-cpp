// ============================================================
// main.cpp — Entry Point
// ============================================================
#include "server.h"
#include "utils.h"
#include <iostream>
#include <stdexcept>
#include <csignal>

// Default port — can override via command line arg
static constexpr int DEFAULT_PORT = 8080;

// Graceful Ctrl+C handling
static void signalHandler(int signum) {
    Logger::instance().info("Received signal " + std::to_string(signum) +
                            " — shutting down server.");
    std::exit(0);
}

int main(int argc, char* argv[]) {
    // Register SIGINT (Ctrl+C) handler
    std::signal(SIGINT, signalHandler);

    int port = DEFAULT_PORT;

    // Allow: ./webserver 9090
    if (argc >= 2) {
        try {
            port = std::stoi(argv[1]);
        } catch (...) {
            std::cerr << "Invalid port argument. Using default " 
                      << DEFAULT_PORT << "\n";
        }
    }

    try {
        Logger::instance().info("=== Multithreaded HTTP Web Server ===");
        Server server(port);
        server.run();
    } catch (const std::exception& e) {
        Logger::instance().error(std::string("Fatal: ") + e.what());
        return 1;
    }

    return 0;
}
