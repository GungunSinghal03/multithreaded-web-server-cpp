// ============================================================
// thread_pool.cpp — Thread Pool Implementation
//
// CONCEPT: Instead of spawning a new thread per HTTP request
// (expensive: ~1ms + memory per thread), we pre-create N threads
// that share a task queue. When a request arrives, we just push
// a task — no thread creation cost at all.
//
// DESIGN:
//   ┌────────────────────────────────────┐
//   │   Server accepts client            │
//   │       ↓                            │
//   │   pool.enqueue(task)               │
//   │       ↓                            │
//   │   [task queue]  ←→ mutex + CV      │
//   │       ↓                            │
//   │   Worker thread wakes → runs task  │
//   └────────────────────────────────────┘
// ============================================================

#include "thread_pool.h"
#include <stdexcept>

// ---- Constructor -------------------------------------------
ThreadPool::ThreadPool(size_t numThreads) : stop_(false) {
    if (numThreads == 0)
        throw std::invalid_argument("Thread pool size must be > 0");

    // Spawn worker threads immediately; each runs workerLoop()
    workers_.reserve(numThreads);
    for (size_t i = 0; i < numThreads; ++i) {
        workers_.emplace_back(&ThreadPool::workerLoop, this);
    }
}

// ---- Destructor --------------------------------------------
ThreadPool::~ThreadPool() {
    // Signal all workers to stop after finishing current tasks
    stop_.store(true);
    cv_.notify_all();  // Wake every sleeping worker

    // Wait for each worker to exit cleanly
    for (auto& t : workers_) {
        if (t.joinable())
            t.join();
    }
}

// ---- enqueue -----------------------------------------------
// Called from the main (acceptor) thread.
// Pushes a task onto the shared queue and wakes ONE worker.
void ThreadPool::enqueue(std::function<void()> task) {
    {
        // Lock is scoped — released when `lock` goes out of scope
        std::lock_guard<std::mutex> lock(queueMutex_);
        tasks_.push(std::move(task));
    }
    cv_.notify_one();  // Wake exactly one waiting worker
}

// ---- workerLoop --------------------------------------------
// Each worker runs this loop forever until stop_ is set.
// Pattern: "wait for work → take work → do work → repeat"
void ThreadPool::workerLoop() {
    while (true) {
        std::function<void()> task;

        {
            // Unique_lock needed for condition_variable::wait()
            std::unique_lock<std::mutex> lock(queueMutex_);

            // Sleep until: there's a task OR we're shutting down
            cv_.wait(lock, [this] {
                return stop_.load() || !tasks_.empty();
            });

            // If shutting down and no tasks left — exit thread
            if (stop_.load() && tasks_.empty())
                return;

            // Take ownership of the front task (move is cheap)
            task = std::move(tasks_.front());
            tasks_.pop();
        }
        // Lock released here — other workers can grab tasks now

        // Execute the task (handles one HTTP client connection)
        task();
    }
}
