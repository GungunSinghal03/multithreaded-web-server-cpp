// ============================================================
// request_handler.cpp — HTTP Request Parser & Response Builder
//
// CONCEPT: HTTP is just text over TCP.
// A GET request looks like:
//
//   GET /index.html HTTP/1.1\r\n
//   Host: localhost:8080\r\n
//   \r\n
//
// We read that text, extract the path, find the file on disk,
// and write back a properly formatted HTTP response.
// ============================================================

#include "request_handler.h"
#include "utils.h"
#include <sstream>
#include <fstream>
#include <filesystem>

namespace fs = std::filesystem;

// ---- Public entry point ------------------------------------
std::string RequestHandler::handle(const std::string& rawRequest,
                                   const std::string& staticRoot) {
    if (rawRequest.empty())
        return build404Response();

    HttpRequest req = parseRequest(rawRequest);

    // Only support GET for now
    if (req.method != "GET")
        return build404Response();

    // Map "/" → "/index.html"
    std::string filePath = req.path;
    if (filePath == "/" || filePath.empty())
        filePath = "/index.html";

    // Security: reject paths with ".." to prevent directory traversal
    // e.g. "/../../../etc/passwd"
    if (filePath.find("..") != std::string::npos)
        return build404Response();

    std::string fullPath = staticRoot + filePath;

    std::string body = readFile(fullPath);
    if (body.empty())
        return build404Response();

    return buildOkResponse(body, getMimeType(fullPath));
}

// ---- parseRequest ------------------------------------------
// Extracts the first line: "GET /path HTTP/1.1"
HttpRequest RequestHandler::parseRequest(const std::string& rawRequest) {
    HttpRequest req;
    std::istringstream stream(rawRequest);
    // First line contains method, path, version separated by spaces
    stream >> req.method >> req.path >> req.version;
    return req;
}

// ---- buildOkResponse ---------------------------------------
// HTTP response format:
//   STATUS_LINE\r\n
//   HEADERS\r\n
//   \r\n
//   BODY
std::string RequestHandler::buildOkResponse(const std::string& body,
                                            const std::string& contentType) {
    std::ostringstream resp;
    resp << "HTTP/1.1 200 OK\r\n"
         << "Content-Type: "   << contentType          << "\r\n"
         << "Content-Length: " << body.size()           << "\r\n"
         << "Connection: close\r\n"
         << "\r\n"
         << body;
    return resp.str();
}

// ---- build404Response --------------------------------------
std::string RequestHandler::build404Response() {
    std::string body =
        "<!DOCTYPE html><html><head><title>404 Not Found</title></head>"
        "<body><h1>404 - Page Not Found</h1>"
        "<p>The resource you requested does not exist.</p></body></html>";

    std::ostringstream resp;
    resp << "HTTP/1.1 404 Not Found\r\n"
         << "Content-Type: text/html\r\n"
         << "Content-Length: " << body.size() << "\r\n"
         << "Connection: close\r\n"
         << "\r\n"
         << body;
    return resp.str();
}

// ---- readFile ----------------------------------------------
std::string RequestHandler::readFile(const std::string& filepath) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open())
        return "";

    // Read entire file into a string
    return std::string(
        std::istreambuf_iterator<char>(file),
        std::istreambuf_iterator<char>()
    );
}

// ---- getMimeType -------------------------------------------
// Browsers need to know what kind of content they're receiving
std::string RequestHandler::getMimeType(const std::string& filepath) {
    std::string ext = fs::path(filepath).extension().string();

    if (ext == ".html" || ext == ".htm") return "text/html; charset=utf-8";
    if (ext == ".css")                   return "text/css";
    if (ext == ".js")                    return "application/javascript";
    if (ext == ".json")                  return "application/json";
    if (ext == ".png")                   return "image/png";
    if (ext == ".jpg" || ext == ".jpeg") return "image/jpeg";
    if (ext == ".ico")                   return "image/x-icon";
    if (ext == ".txt")                   return "text/plain";

    return "application/octet-stream";  // Unknown type → binary fallback
}
