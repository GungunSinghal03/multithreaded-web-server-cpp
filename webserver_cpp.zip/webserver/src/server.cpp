// ============================================================
// server.cpp — TCP Server with Thread Pool
//
// CONCEPT: Socket Programming Basics
// ─────────────────────────────────
// A socket is a FILE DESCRIPTOR — just like opening a file,
// but the "file" is a network connection.
//
// The lifecycle of a server socket:
//
//   socket()  → creates the socket fd
//     ↓
//   setsockopt() → set options (reuse port)
//     ↓
//   bind()    → attach it to a port (e.g. 8080)
//     ↓
//   listen()  → start accepting connections (backlog queue)
//     ↓
//   accept()  → blocks until a client connects → returns client_fd
//     ↓
//   read()/write() → communicate with client
//     ↓
//   close()   → done with this client
//
// ============================================================

#include "server.h"
#include "thread_pool.h"
#include "request_handler.h"
#include "utils.h"

#include <sys/socket.h>   // socket(), bind(), listen(), accept()
#include <netinet/in.h>   // sockaddr_in, htons(), INADDR_ANY
#include <unistd.h>       // close(), read(), write()
#include <cstring>        // memset()
#include <stdexcept>
#include <string>
#include <sstream>

// How many client connections can queue up waiting for accept()
static constexpr int BACKLOG      = 128;

// Max bytes we read from a single HTTP request
static constexpr int BUFFER_SIZE  = 4096;

// Number of pre-spawned worker threads in the pool
static constexpr int THREAD_COUNT = 8;

// Where our static HTML/CSS/JS files live
static const std::string STATIC_ROOT = "static";

// ---- Constructor -------------------------------------------
Server::Server(int port) : port_(port), server_fd_(-1) {
    setupSocket();
}

// ---- Destructor --------------------------------------------
Server::~Server() {
    if (server_fd_ >= 0)
        close(server_fd_);
}

// ---- setupSocket -------------------------------------------
// Creates and configures the listening socket.
// Each syscall returns -1 on failure; we throw on errors.
void Server::setupSocket() {
    // 1. Create socket
    //    AF_INET  = IPv4
    //    SOCK_STREAM = TCP (reliable, ordered, connection-based)
    //    0 = auto-select protocol (TCP for SOCK_STREAM)
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ < 0)
        throw std::runtime_error("socket() failed: " +
                                 std::string(strerror(errno)));

    // 2. Allow port reuse — without this, restarting the server
    //    within ~60 seconds gives "Address already in use"
    int opt = 1;
    if (setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR,
                   &opt, sizeof(opt)) < 0)
        throw std::runtime_error("setsockopt() failed: " +
                                 std::string(strerror(errno)));

    // 3. Bind: associate the socket with our port
    //    sockaddr_in = IPv4 address structure
    struct sockaddr_in addr{};
    addr.sin_family      = AF_INET;          // IPv4
    addr.sin_port        = htons(port_);     // host→network byte order
    addr.sin_addr.s_addr = INADDR_ANY;       // Accept from any interface

    if (bind(server_fd_, (struct sockaddr*)&addr, sizeof(addr)) < 0)
        throw std::runtime_error("bind() failed on port " +
                                 std::to_string(port_) + ": " +
                                 std::string(strerror(errno)));

    // 4. Listen: kernel queues up to BACKLOG pending connections
    if (listen(server_fd_, BACKLOG) < 0)
        throw std::runtime_error("listen() failed: " +
                                 std::string(strerror(errno)));

    Logger::instance().info("Server socket ready on port " +
                            std::to_string(port_));
}

// ---- run ---------------------------------------------------
// The main accept loop. Runs forever.
// For each accepted client, enqueues work to the thread pool.
void Server::run() {
    Logger::instance().info(
        "Server running on http://localhost:" + std::to_string(port_));
    Logger::instance().info(
        "Thread pool: " + std::to_string(THREAD_COUNT) + " workers");

    // Create thread pool — workers start immediately
    ThreadPool pool(THREAD_COUNT);

    while (true) {
        struct sockaddr_in clientAddr{};
        socklen_t clientLen = sizeof(clientAddr);

        // accept() BLOCKS here until a new client connects.
        // Returns a NEW file descriptor just for that client.
        // server_fd_ stays open and keeps accepting new ones.
        int client_fd = accept(server_fd_,
                               (struct sockaddr*)&clientAddr,
                               &clientLen);

        if (client_fd < 0) {
            Logger::instance().error("accept() failed: " +
                                     std::string(strerror(errno)));
            continue;  // Don't crash — just try next accept()
        }

        // Enqueue the client to be handled by a worker thread.
        // Capture client_fd by value (not reference!) so each
        // lambda gets its own copy.
        pool.enqueue([this, client_fd]() {
            handleClient(client_fd);
        });
    }
}

// ---- handleClient ------------------------------------------
// Runs in a worker thread. Does the full request→response cycle.
void Server::handleClient(int client_fd) {
    // Get client IP for logging (before we close the socket)
    std::string clientIp = Utils::getClientIp(client_fd);

    // Read the HTTP request bytes from the client
    char buffer[BUFFER_SIZE] = {};
    ssize_t bytesRead = read(client_fd, buffer, sizeof(buffer) - 1);

    if (bytesRead > 0) {
        std::string rawRequest(buffer, bytesRead);

        // Parse and generate response
        RequestHandler handler;
        std::string response = handler.handle(rawRequest, STATIC_ROOT);

        // Extract method/path for logging (simple parse)
        std::string method = "UNKNOWN", path = "/";
        {
            std::istringstream ss(rawRequest);
            ss >> method >> path;
        }

        // Determine status code for logging
        int statusCode = (response.find("200 OK") != std::string::npos)
                         ? 200 : 404;

        Logger::instance().logRequest(clientIp, method, path, statusCode);

        // Send the complete HTTP response back to the browser
        // write() returns bytes written; we ignore partial writes
        // for simplicity (production would loop until all sent)
        write(client_fd, response.c_str(), response.size());
    }

    // Always close the client socket when done.
    // Missing this causes a file descriptor leak!
    close(client_fd);
}
