#pragma once
// ============================================================
// request_handler.h — HTTP Request Parser & Response Builder
// Parses raw HTTP text → decides what to serve → builds reply
// ============================================================
#include <string>

// Holds the parsed fields from an HTTP request line
struct HttpRequest {
    std::string method;   // "GET", "POST", etc.
    std::string path;     // "/index.html", "/about", etc.
    std::string version;  // "HTTP/1.1"
};

class RequestHandler {
public:
    // Entry point: given raw bytes from a client socket, return
    // a complete HTTP response string (headers + body).
    // `staticRoot` is the folder where HTML files live.
    std::string handle(const std::string& rawRequest,
                       const std::string& staticRoot);

private:
    // Parses the first line: "GET /index.html HTTP/1.1"
    HttpRequest parseRequest(const std::string& rawRequest);

    // Builds a 200 OK response with the file contents as body
    std::string buildOkResponse(const std::string& body,
                                const std::string& contentType);

    // Builds a 404 Not Found response with a simple HTML page
    std::string build404Response();

    // Reads entire file into a string; returns "" if not found
    std::string readFile(const std::string& filepath);

    // Maps file extension → MIME type (e.g. ".html" → "text/html")
    std::string getMimeType(const std::string& filepath);
};
