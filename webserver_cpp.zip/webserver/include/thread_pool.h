#pragma once
// ============================================================
// thread_pool.h — Fixed-size Thread Pool Declaration
// Pre-spawns N worker threads that pull tasks from a queue.
// Avoids the overhead of creating/destroying threads per request.
// ============================================================
#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <atomic>

class ThreadPool {
public:
    // Spawns `numThreads` worker threads immediately
    explicit ThreadPool(size_t numThreads);

    // Gracefully shuts down: finishes queued tasks then joins threads
    ~ThreadPool();

    // Adds a callable task (lambda, function, etc.) to the work queue
    void enqueue(std::function<void()> task);

private:
    std::vector<std::thread>          workers_;   // Pool of worker threads
    std::queue<std::function<void()>> tasks_;     // Pending task queue

    std::mutex              queueMutex_;  // Guards access to tasks_
    std::condition_variable cv_;          // Workers sleep/wake on this
    std::atomic<bool>       stop_;        // Signals shutdown to workers

    // Each worker runs this loop: wait → pop task → execute → repeat
    void workerLoop();
};
