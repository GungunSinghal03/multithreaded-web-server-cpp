#pragma once
// ============================================================
// utils.h — Logging & Helper Utilities
// ============================================================
#include <string>
#include <mutex>

// ---- Logger -------------------------------------------------
// Thread-safe logger. Uses a mutex so concurrent threads don't
// interleave their output lines.
class Logger {
public:
    // Singleton access — one shared logger for the whole process
    static Logger& instance();

    // Logs an INFO message with timestamp to stdout + log file
    void info(const std::string& message);

    // Logs an ERROR message with timestamp to stderr + log file
    void error(const std::string& message);

    // Logs an HTTP request line nicely formatted
    void logRequest(const std::string& clientIp,
                    const std::string& method,
                    const std::string& path,
                    int statusCode);

private:
    Logger();   // Private constructor (singleton pattern)
    ~Logger();

    std::mutex  mutex_;    // Protects simultaneous writes
    std::string logFile_;  // Path to the log file on disk
};

// ---- Helpers ------------------------------------------------
namespace Utils {
    // Returns current time as "YYYY-MM-DD HH:MM:SS"
    std::string currentTimestamp();

    // Extracts the IP string from a sockaddr_in structure
    // (avoids exposing sys headers in every translation unit)
    std::string getClientIp(int client_fd);
}
