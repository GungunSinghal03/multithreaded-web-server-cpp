#pragma once
// ============================================================
// server.h — TCP Server Declaration
// Encapsulates socket creation, binding, and client acceptance
// ============================================================
#include <string>

class Server {
public:
    // Constructor: takes port number to listen on
    explicit Server(int port);

    // Destructor: closes server socket cleanly
    ~Server();

    // Blocking call: starts accepting connections forever
    void run();

private:
    int port_;          // Port the server listens on (e.g. 8080)
    int server_fd_;     // File descriptor for the listening socket

    // Creates, binds, and starts listening on the socket
    void setupSocket();

    // Handles a single accepted client connection
    // Called per-thread from the thread pool
    void handleClient(int client_fd);
};
