# Multithreaded HTTP Web Server in C++
> Qualcomm-level Systems Programming Project

---

## 📁 Project Structure

```
webserver/
├── include/               ← Header files (declarations)
│   ├── server.h           ← TCP Server class
│   ├── thread_pool.h      ← Fixed-size Thread Pool
│   ├── request_handler.h  ← HTTP Parser & Response Builder
│   └── utils.h            ← Logger & Helpers
├── src/                   ← Source files (implementations)
│   ├── main.cpp           ← Entry point
│   ├── server.cpp         ← Socket lifecycle + accept loop
│   ├── thread_pool.cpp    ← Worker threads + task queue
│   ├── request_handler.cpp← HTTP parsing + file serving
│   └── utils.cpp          ← Logging + timestamp helpers
├── static/                ← HTML files served to browsers
│   ├── index.html         ← Home page
│   └── about.html         ← About page
├── logs/                  ← server.log written here at runtime
└── Makefile               ← Build system
```

---

## 🚀 Build & Run

```bash
# Prerequisites: g++ with C++17 support, Linux/macOS
make          # compile
./webserver   # run on port 8080 (default)
./webserver 9090  # run on custom port

# Or one-liner:
make run
```

Then open your browser: **http://localhost:8080**

---

## 🗺️ 5-Day Learning Roadmap

| Day | Topic | What You Build |
|-----|-------|----------------|
| **Day 1** | Socket Programming Basics | TCP server that accepts connections |
| **Day 2** | Multithreading | One thread per client (naive) |
| **Day 3** | HTTP Parsing | Parse GET requests, serve HTML |
| **Day 4** | Thread Pool | Replace per-client threads with pool |
| **Day 5** | Logging + Polish | Timestamped logs, proper error handling |

---

## 🧠 Key Concepts (Interview Ready)

### 1. Socket File Descriptors
A socket is just a file descriptor — an integer handle into the kernel's I/O table. The sequence:
```
socket() → bind() → listen() → accept() → read()/write() → close()
```

### 2. Why Thread Pool?
- **Naive approach**: `new thread` per request → O(n) threads for n clients
- **Problem**: Thread creation = ~1ms + 1–8MB stack memory each
- **Thread pool fix**: Pre-spawn N threads. Requests queue up. Zero creation overhead.
- **Classic pattern**: Producer-Consumer with mutex + condition variable

### 3. HTTP/1.1 Anatomy
```
GET /index.html HTTP/1.1\r\n     ← Request line
Host: localhost:8080\r\n         ← Headers
\r\n                             ← Blank line = end of headers
                                 ← (Body would follow for POST)
```

### 4. Why `\r\n`?
HTTP spec (RFC 7230) requires CRLF line endings. Browsers enforce this.

### 5. Race Conditions & Mutex
Multiple threads sharing the logger → without a mutex, their output lines interleave. `std::lock_guard` ensures only one thread writes at a time.

---

## 🔧 Test Commands

```bash
# Test with curl (verbose shows headers)
curl -v http://localhost:8080/
curl -v http://localhost:8080/about.html
curl -v http://localhost:8080/notfound.html  # Should return 404

# Test concurrent connections (10 parallel requests)
for i in {1..10}; do curl -s http://localhost:8080/ > /dev/null & done; wait

# Watch live logs
tail -f logs/server.log
```

---

## 🎯 Qualcomm Interview Talking Points

1. **"Walk me through your socket lifecycle"** → socket → bind → listen → accept loop
2. **"Why thread pool over thread-per-request?"** → amortize creation cost, bound resource usage
3. **"How do you prevent data races in the logger?"** → `std::mutex` + `std::lock_guard` RAII
4. **"What's the condition variable for?"** → efficient sleep/wake without busy-polling
5. **"How would you scale this further?"** → epoll/io_uring (async I/O), load balancer, HTTP keep-alive
